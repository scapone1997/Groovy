package com.mypackage.builders;

/**
 * I builder sono un modo conveniente e pratico per costruire un oggetto.
 * Vedremo come costruire builder per ottenere oggetti XML, HTML e JSON
 */
public class Testo {
}
