package com.mypackage.intro

import groovy.transform.ToString
import groovy.transform.Sortable

@ToString
@Sortable
class Person {
    String first
    String last
}



